const urls = {
    webView: 'https://nginx:givemeaccess@hashtag.credit/user/mobile/credit-application2/'
}

export default urls;
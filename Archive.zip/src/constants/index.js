
export const INCREMENT = 'INCREMENT';

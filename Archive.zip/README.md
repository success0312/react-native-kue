# kue-mobile-app

## Launch instructions

First install depedencies (if you've got permission denied message use sudo)

```
npm install
```

Then you need to install `react-native-cli` globally:

```
npm install -g react-native-cli
```

Also you need to install watchman from macport or homebrew:

```
sudo port -v install watchman
sudo brew install watchman
```

Launch ios simulation

```
react-native run-ios
```

Launch android simulation

```
react-native run-android
```

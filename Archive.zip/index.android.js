// import App from './src/index'
// import {AppRegistry} from 'react-native'

// AppRegistry.registerComponent('Kue', () => App);
import './src/index';